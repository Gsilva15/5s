from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src.models.user import Cycle, AreaAssignment, Evaluation, Area, User, RankingHistory, db
from datetime import datetime, date
import calendar

cycles_bp = Blueprint('cycles', __name__)

def admin_required(f):
    """Decorator para verificar se o usuário é admin"""
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            return jsonify({'error': 'Acesso negado. Apenas administradores podem acessar esta funcionalidade.'}), 403
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@cycles_bp.route('/', methods=['GET'])
@login_required
def get_cycles():
    try:
        cycles = Cycle.query.order_by(Cycle.created_at.desc()).all()
        return jsonify([cycle.to_dict() for cycle in cycles]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cycles_bp.route('/active', methods=['GET'])
@login_required
def get_active_cycle():
    try:
        active_cycle = Cycle.query.filter_by(is_active=True).first()
        if active_cycle:
            return jsonify(active_cycle.to_dict()), 200
        else:
            return jsonify({'message': 'Nenhum ciclo ativo encontrado'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cycles_bp.route('/', methods=['POST'])
@login_required
@admin_required
def create_cycle():
    try:
        data = request.get_json()
        name = data.get('name')
        start_date_str = data.get('start_date')
        end_date_str = data.get('end_date')
        
        if not name or not start_date_str or not end_date_str:
            return jsonify({'error': 'Nome, data de início e data de fim são obrigatórios'}), 400
        
        # Converter strings para objetos date
        try:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Formato de data inválido. Use YYYY-MM-DD'}), 400
        
        if start_date >= end_date:
            return jsonify({'error': 'Data de início deve ser anterior à data de fim'}), 400
        
        # Verificar se já existe um ciclo ativo
        active_cycle = Cycle.query.filter_by(is_active=True).first()
        if active_cycle:
            return jsonify({'error': 'Já existe um ciclo ativo. Finalize-o antes de criar um novo.'}), 400
        
        # Verificar se já existe ciclo com este nome
        if Cycle.query.filter_by(name=name).first():
            return jsonify({'error': 'Já existe um ciclo com este nome'}), 400
        
        cycle = Cycle(
            name=name,
            start_date=start_date,
            end_date=end_date,
            is_active=True
        )
        
        db.session.add(cycle)
        db.session.commit()
        
        return jsonify({
            'message': 'Ciclo criado com sucesso',
            'cycle': cycle.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@cycles_bp.route('/create-monthly', methods=['POST'])
@login_required
@admin_required
def create_monthly_cycle():
    """Cria um ciclo mensal automaticamente"""
    try:
        data = request.get_json()
        year = data.get('year', datetime.now().year)
        month = data.get('month', datetime.now().month)
        
        if month < 1 or month > 12:
            return jsonify({'error': 'Mês deve estar entre 1 e 12'}), 400
        
        # Verificar se já existe um ciclo ativo
        active_cycle = Cycle.query.filter_by(is_active=True).first()
        if active_cycle:
            return jsonify({'error': 'Já existe um ciclo ativo. Finalize-o antes de criar um novo.'}), 400
        
        # Gerar nome do ciclo
        month_names = [
            'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
            'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
        ]
        cycle_name = f"{month_names[month-1]} {year}"
        
        # Verificar se já existe ciclo com este nome
        if Cycle.query.filter_by(name=cycle_name).first():
            return jsonify({'error': f'Já existe um ciclo para {cycle_name}'}), 400
        
        # Calcular primeiro e último dia do mês
        start_date = date(year, month, 1)
        last_day = calendar.monthrange(year, month)[1]
        end_date = date(year, month, last_day)
        
        cycle = Cycle(
            name=cycle_name,
            start_date=start_date,
            end_date=end_date,
            is_active=True
        )
        
        db.session.add(cycle)
        db.session.commit()
        
        return jsonify({
            'message': f'Ciclo mensal para {cycle_name} criado com sucesso',
            'cycle': cycle.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@cycles_bp.route('/<int:cycle_id>/complete', methods=['POST'])
@login_required
@admin_required
def complete_cycle(cycle_id):
    try:
        cycle = Cycle.query.get_or_404(cycle_id)
        
        if not cycle.is_active:
            return jsonify({'error': 'Este ciclo não está ativo'}), 400
        
        if cycle.is_completed:
            return jsonify({'error': 'Este ciclo já foi finalizado'}), 400
        
        # Gerar e salvar o ranking antes de finalizar o ciclo
        evaluations = db.session.query(Evaluation, Area, User).join(
            Area, Evaluation.area_id == Area.id
        ).join(
            User, Evaluation.auditor_id == User.id
        ).filter(
            Evaluation.cycle_id == cycle_id
        ).order_by(Evaluation.total_score.desc()).all()
        
        # Salvar ranking histórico
        position = 1
        for evaluation, area, auditor in evaluations:
            ranking_entry = RankingHistory(
                cycle_id=cycle_id,
                area_id=area.id,
                area_name=area.name,
                position=position,
                total_score=evaluation.total_score,
                auditor_name=auditor.username,
                evaluation_id=evaluation.id,
                senso1_score=evaluation.senso1_score,
                senso2_score=evaluation.senso2_score,
                senso3_score=evaluation.senso3_score,
                senso4_score=evaluation.senso4_score,
                senso5_score=evaluation.senso5_score
            )
            db.session.add(ranking_entry)
            position += 1
        
        # Marcar ciclo como completo e inativo
        cycle.is_active = False
        cycle.is_completed = True
        
        db.session.commit()
        
        return jsonify({
            'message': 'Ciclo finalizado com sucesso e ranking salvo',
            'cycle': cycle.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@cycles_bp.route('/<int:cycle_id>/status', methods=['GET'])
@login_required
def get_cycle_status(cycle_id):
    """Busca o status detalhado de um ciclo"""
    try:
        cycle = Cycle.query.get_or_404(cycle_id)
        
        # Buscar atribuições do ciclo
        assignments = AreaAssignment.query.filter_by(cycle_id=cycle_id).all()
        total_assignments = len(assignments)
        
        # Buscar avaliações do ciclo
        evaluations = Evaluation.query.filter_by(cycle_id=cycle_id).all()
        completed_evaluations = len(evaluations)
        
        # Calcular progresso
        progress_percentage = (completed_evaluations / total_assignments * 100) if total_assignments > 0 else 0
        
        # Buscar detalhes das atribuições
        assignment_details = []
        for assignment in assignments:
            area = Area.query.get(assignment.area_id)
            auditor = User.query.get(assignment.auditor_id)
            evaluation = Evaluation.query.filter_by(
                area_id=assignment.area_id,
                auditor_id=assignment.auditor_id,
                cycle_id=cycle_id
            ).first()
            
            assignment_details.append({
                'assignment_id': assignment.id,
                'area_name': area.name if area else 'Área não encontrada',
                'auditor_name': auditor.username if auditor else 'Auditor não encontrado',
                'is_evaluated': evaluation is not None,
                'evaluation_score': evaluation.total_score if evaluation else None,
                'evaluation_date': evaluation.created_at.isoformat() if evaluation else None
            })
        
        return jsonify({
            'cycle': cycle.to_dict(),
            'total_assignments': total_assignments,
            'completed_evaluations': completed_evaluations,
            'progress_percentage': round(progress_percentage, 2),
            'assignments': assignment_details
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@cycles_bp.route('/<int:cycle_id>/ranking', methods=['GET'])
@login_required
def get_cycle_ranking(cycle_id):
    """Gera o ranking das áreas para um ciclo específico"""
    try:
        cycle = Cycle.query.get_or_404(cycle_id)
        
        # Buscar todas as avaliações do ciclo com informações das áreas
        evaluations = db.session.query(Evaluation, Area).join(
            Area, Evaluation.area_id == Area.id
        ).filter(
            Evaluation.cycle_id == cycle_id
        ).order_by(Evaluation.total_score.desc()).all()
        
        ranking = []
        position = 1
        
        for evaluation, area in evaluations:
            auditor = User.query.get(evaluation.auditor_id)
            
            ranking.append({
                'position': position,
                'area_id': area.id,
                'area_name': area.name,
                'total_score': evaluation.total_score,
                'auditor_name': auditor.username if auditor else 'Auditor não encontrado',
                'evaluation_date': evaluation.created_at.isoformat() if evaluation.created_at else None,
                'evaluation_id': evaluation.id, # Adicionado o ID da avaliação
                'senso_scores': {
                    'seiri': evaluation.senso1_score,
                    'seiton': evaluation.senso2_score,
                    'seiso': evaluation.senso3_score,
                    'seiketsu': evaluation.senso4_score,
                    'shitsuke': evaluation.senso5_score
                }
            })
            position += 1
        
        return jsonify({
            'cycle': cycle.to_dict(),
            'ranking': ranking,
            'total_evaluations': len(ranking)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500



@cycles_bp.route('/<int:cycle_id>/ranking-history', methods=['GET'])
@login_required
def get_cycle_ranking_history(cycle_id):
    """Busca o ranking histórico salvo de um ciclo específico"""
    try:
        cycle = Cycle.query.get_or_404(cycle_id)
        
        # Verificar se existe ranking histórico para este ciclo
        ranking_history = RankingHistory.query.filter_by(cycle_id=cycle_id).order_by(RankingHistory.position).all()
        
        if not ranking_history:
            # Se não há ranking histórico, gerar ranking dinâmico (para ciclos ativos)
            if cycle.is_active:
                return get_cycle_ranking(cycle_id)
            else:
                return jsonify({
                    'cycle': cycle.to_dict(),
                    'ranking': [],
                    'total_evaluations': 0,
                    'message': 'Nenhum ranking histórico encontrado para este ciclo'
                }), 200
        
        # Converter ranking histórico para formato de resposta
        ranking = []
        for entry in ranking_history:
            ranking.append({
                'position': entry.position,
                'area_id': entry.area_id,
                'area_name': entry.area_name,
                'total_score': entry.total_score,
                'auditor_name': entry.auditor_name,
                'evaluation_id': entry.evaluation_id,
                'senso_scores': {
                    'seiri': entry.senso1_score,
                    'seiton': entry.senso2_score,
                    'seiso': entry.senso3_score,
                    'seiketsu': entry.senso4_score,
                    'shitsuke': entry.senso5_score
                }
            })
        
        return jsonify({
            'cycle': cycle.to_dict(),
            'ranking': ranking,
            'total_evaluations': len(ranking),
            'is_historical': True
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

